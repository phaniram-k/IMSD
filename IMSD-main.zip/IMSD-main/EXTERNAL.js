function externalfunction(){
    alert("Hello from external javascript!!!");
}